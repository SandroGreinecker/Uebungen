using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace UserControlUebung
{
    /// <summary>
    /// Interaction logic for UserControl1.xaml
    /// </summary>
    public partial class UserControl1 : UserControl
    {
        public event EventHandler<EventArgs> ValueChanged;
        public UserControl1()
        {
            InitializeComponent();
        }

        private void slideruser_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            lbluser.Content = $"{e.NewValue:0}";
            txtboxuser.Text = $"{e.NewValue:0}";
            if (ValueChanged == null) return;
            ValueChanged(this, new ValueChangedEventArgs
            {
                Val = e.NewValue,
                Clock = DateTime.Now
            });
        }
        
        private double val;
        [Category("Data"), Description("Get the current value")]
        public double Val
        {
            get { return val; }
            set { val = value;
                slideruser.Value = val;
            }
        }
    }
}