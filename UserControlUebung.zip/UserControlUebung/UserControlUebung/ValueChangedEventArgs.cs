﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UserControlUebung
{
    public class ValueChangedEventArgs:EventArgs
    {
        public double Val { get; set; }
        public DateTime Clock { get; set; }

        
        public delegate void ValueChangedEventHandler(object sender, ValueChangedEventArgs e);
    }
}
